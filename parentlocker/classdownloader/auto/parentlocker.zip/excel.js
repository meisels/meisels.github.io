if (window.location.hostname.match(/\w*\.\w*$/gi)[0] + window.location.pathname == "parentlocker.com/sis/directory.php" && new URL(location.href).searchParams.get('i') != null && document.body.innerHTML != "Unauthorized Access.") {
	var buttonLink = document.createElement("a");
	var buttonPicture = document.createElement("img");
	var buttonText = document.createTextNode("Excel");
	buttonPicture.setAttribute("src", "../images/page_white_excel.png");
	buttonLink.setAttribute("href", "javascript:window.location.replace(window.location.protocol + '//' + window.location.host + window.location.pathname + window.location.search + '&media=excel');");
	buttonLink.setAttribute("class", "toplink");
	buttonLink.appendChild(buttonPicture);
	buttonLink.appendChild(buttonText);
	document.getElementsByClassName("noprint noprinttop")[0].id = "addExcel";
	addId = document.getElementById("addExcel");
	addId.insertBefore(buttonLink, addId.childNodes[2]);
};