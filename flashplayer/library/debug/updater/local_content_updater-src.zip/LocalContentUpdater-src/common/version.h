//
// version.h
//

#ifndef _MFLCU_VERSION_H_
#define _MFLCU_VERSION_H_


#define APPVERSION "0.22"


#endif  /* _MFLCU_VERSION_H_ */

// End of file.
